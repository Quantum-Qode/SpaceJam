package com.example.spacejam

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Waiting_time : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_waiting_time)

    }
}