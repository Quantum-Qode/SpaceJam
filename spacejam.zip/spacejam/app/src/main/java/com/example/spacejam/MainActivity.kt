package com.example.spacejam

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val name:EditText=findViewById(R.id.name_of_customer)
        val name_final= name.text.toString()
        val phone_no:EditText=findViewById(R.id.phone_no)
        val phone_final= phone_no.text.toString()
        val number:EditText=findViewById(R.id.no_of_people)
        val next:Button=findViewById(R.id.next_button)
        next.setOnClickListener {
            if(true){
                val number_final=number.text.toString()
                val see_timer:Button=findViewById(R.id.seetimer_button)
                see_timer.setOnClickListener {
                        val intent= Intent(this,Waiting_time::class.java)
                        startActivity(intent)
                    }
                }
            else{
                //val toast= Toast.makeText(this,"You have already registered")
                val see_timer:Button=findViewById(R.id.seetimer_button)
                see_timer.setOnClickListener {
                    val intent= Intent(this,Waiting_time::class.java)
                    startActivity(intent)
            }

        }
    }
}}