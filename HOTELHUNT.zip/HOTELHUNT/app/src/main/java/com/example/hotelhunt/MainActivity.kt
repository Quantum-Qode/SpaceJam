package com.example.hotelhunt

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val customerB: Button = findViewById(R.id.customer1)
        customerB.setOnClickListener {
            val intent = Intent(this,customer::class.java)
            startActivity(intent)
        }
        val restaurantB: Button = findViewById(R.id.restaurant1)
        restaurantB.setOnClickListener {
            val intent1 = Intent (this,restaurant::class.java)
            startActivity(intent1)
        }
    }

}