package com.example.hotelhunt

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import java.io.*
import java.util.*

class restaurant : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_restaurant)

        val idX: EditText = findViewById(R.id.hotelIdET)
        val id = idX.text.toString()

        val passwordX: EditText = findViewById(R.id.passwordET)
        val password = passwordX.text.toString()
        val confirm1: Button = findViewById(R.id.Confirm1B)
        val hotelNameX: EditText = findViewById(R.id.hotelnameET)
        val hotelName = hotelNameX.text.toString()
        val seatCapacityX: EditText = findViewById(R.id.seatCapacityET)
        val seatCapacity = seatCapacityX.text.toString()
        val confirm2: Button = findViewById(R.id.confirm2B)
        val next: Button = findViewById(R.id.nextB)
        val object01=HotelFileHandling();

        next.setOnClickListener {


            if (object01.CreateFile(id)) {//checking if Id is that of an already registered hotel
                passwordX.setVisibility(View.VISIBLE);
                confirm1.setVisibility(View.VISIBLE);

                confirm1.setOnClickListener {
                    if (object01.CheckLogin(id,password)) {//checking if password is correct
                        val intent1 = Intent(this,seatingCapacity::class.java)
                        startActivity(intent1)
                    } else {//toast
                    }
                }


            } else {
                passwordX.setVisibility(View.VISIBLE);
                hotelNameX.setVisibility(View.VISIBLE);
                seatCapacityX.setVisibility(View.VISIBLE);
                confirm2.setVisibility(View.VISIBLE);


                confirm2.setOnClickListener{
                    object01.CreateFile(id);
                    object01.WriteFile(id,password,hotelName,seatCapacity);
                    val intent1 = Intent(this,seatingCapacity::class.java)
                    startActivity(intent1)
                }

            }


        }


    }
}


internal class HotelFileHandling {
    /* var hotelId: String
     var password: String? = null
     var hotelName: String? = null
     var seats :String? = null

     constructor(loginId: String) {
         hotelId = loginId
     }

     constructor(loginId: String, pass_word: String?, hotel_Name: String?, seats_: String) {
         hotelId = loginId
         password = pass_word
         hotelName = hotel_Name
         seats = seats_
     }*/

    fun CreateFile(loginId:String): Boolean {
        var creation = false
        val filename = "$loginId.txt"
        try {
            val obj = File(filename)
            if (obj.createNewFile()) {
                creation = true
            }
        } catch (e: IOException) {
            println("error")
        }
        return creation
    }

    fun WriteFile(loginId: String,passWord:String,hotelname:String,seatCapacity:String) {
        try {
            val filename = "$loginId.txt"
            val myWriter = FileWriter(filename)
            val obj1 = BufferedWriter(myWriter)
            obj1.append(passWord)
            obj1.newLine()
            obj1.append(loginId)
            obj1.newLine()
            obj1.append(hotelname)
            obj1.newLine()
            obj1.append(seatCapacity)
            obj1.close()
        } catch (e: IOException) {
            println("An error occured")
        }
    }

    fun CheckLogin(loginId:String,passWord:String): Boolean {
        val filename = "$loginId.txt"
        var login = false
        try {
            val obj2 = File(filename)
            val obj3 = Scanner(obj2)
            val password2 = obj3.nextLine()
            if (password2.equals(passWord)) {
                login = true
            }
            obj3.close()
        } catch (e: FileNotFoundException) {
            println("An error occurred.")
        }
        return login
    }


}

