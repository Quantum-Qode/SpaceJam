package com.example.hotelhunt

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import java.io.BufferedWriter
import java.io.File
import java.io.FileWriter
import java.io.IOException

class customer : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_customer)
        var totSeats:Int = 200
        val name: EditText =findViewById(R.id.name_of_customer)
        val name_final= name.text.toString()
        val phone_no: EditText =findViewById(R.id.phone_no)
        val phone_final= phone_no.text.toString()
        val obj=UserFileHandling(phone_final)
        val number: EditText =findViewById(R.id.no_of_people)
        val next: Button =findViewById(R.id.next_button)
        next.setOnClickListener {
            if(obj.CreateFile()){
                number.setVisibility(View.VISIBLE)
                val number_final=(number.text.toString()).toInt()
                val see_timer: Button =findViewById(R.id.seetimer_button)
                see_timer.setVisibility(View.VISIBLE)
                val obj2=UserFileHandling(phone_final,name_final,number_final,totSeats)
                obj2.WriteFile()
                see_timer.setOnClickListener {
                    val intent= Intent(this,Waiting_time::class.java)
                    startActivity(intent)
                }
            }
            else{
                //val toast= Toast.makeText(this,"You have already registered")
                val see_timer: Button =findViewById(R.id.seetimer_button)
                see_timer.setOnClickListener {
                    val intent= Intent(this,Waiting_time::class.java)
                    startActivity(intent)
                }

            }
        }
    }}
internal class UserFileHandling {
    var phno:String?=null
    var customerName:String?=null
    var seatsReq:Int = 0
    var totSeats=200
    var t1:Long = 0
    var t2:Long = 0
    var duration:Long = 0
    constructor(PHNO:String) {
        phno = PHNO
    }
    constructor(PHNO:String, cname:String, sreq:Int, totalSeats:Int) {
        phno = PHNO
        customerName = cname
        seatsReq = sreq
        totSeats = totalSeats
    }
    fun CreateFile():Boolean {
        var creation = false
        try
        {
            val filename = phno + ".txt"
            val obj = File(filename)
            if (obj.createNewFile())
            {
                creation = true
            }
        }
        catch (e:IOException) {
            println("file not created")
            e.printStackTrace()
        }
        return creation
    }
    fun WriteFile() {
        val filename="${phno}"+".txt"
        totSeats -= seatsReq
        t1 = (System.currentTimeMillis())

        try
        {
            val myWriter = FileWriter(filename)
            val obj = BufferedWriter(myWriter)
            obj.append(phno)
            obj.newLine()
            obj.append(customerName)
            obj.newLine()
            obj.append((seatsReq).toString())
            obj.close()

        }
        catch(e:IOException){
            println("An Error Occured!!")
        }

    }

    constructor() {
        val filename = phno + "txt"
        val myObj = File(filename)
        if (myObj.delete())
        {
            totSeats += seatsReq
            t2 = (System.currentTimeMillis())
        }
    }
    fun SeatsLeft():Int {
        return totSeats
    }
    fun CustomerName():String? {
        return customerName
    }

}