package com.example.hotelhunt

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class Waiting_time : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_waiting_time)
        val seatsReq=100
        val t=20
        fun duration():Int{
            return t
        }
        var time=duration()
        val a: TextView =findViewById(R.id.textView)
        a.text="${t}"

    }
}