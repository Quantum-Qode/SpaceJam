package com.example.spacejam

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        val idX: EditText = findViewById(R.id.hotelIdET)
        val id = idX.text.toString()
        val passwordX: EditText = findViewById(R.id.passwordET)
        val password = passwordX.text.toString()
        val confirm1: Button = findViewById(R.id.Confirm1B)
        val hotelNameX: EditText = findViewById(R.id.hotelnameET)
        val hotelName = hotelNameX.text.toString()
        val seatCapacityX: EditText = findViewById(R.id.seatCapacityET)
        val seatCapacity = seatCapacityX.text.toString()
        val confirm2: Button = findViewById(R.id.confirm2B)

        val next: Button = findViewById(R.id.nextB)
        next.setOnClickListener {


            if (true) {//checking if Id is that of an already registered hotel
                passwordX.setVisibility(View.VISIBLE);
                confirm1.setVisibility(View.VISIBLE);

                if(true){//checking if password entered is correct
                    confirm1.setOnClickListener{
                        val intent1= Intent(this,MainActivity2::class.java)
                        startActivity(intent1)

                    }




                }


            }


        }


    }
}
